# Programación Creativa - Certamen 2

Profesor: Nicolás Troncoso

Alumno: Pedro Manasevich

Objetivo:
El objetivo para este codigo fue poder visualizar los cambios de Temperatura
y Humedad durante un año, los primeros 6 meses y los ultimos 6 meses.

Para esto utilice la Maxima de ambas variables para poder posicionarlas,
luego utilice la maxima y minima para definir el ancho y el alto de la
ellipse, posterior a eso le asigne un color para poder diferenciar el cambio de día,
debido a la gran similitud en los valores me vi obligado a multiplicar los valores
para lograr un resultado llamativo.


*El paso del tiempo provoca que el circulo crezca.*

*Los valores podrian verse afectados*

*La funcion para ver 1º o 2º mitad de año solo funciona al inicio del sketch*

Usar teclas:
1º 6 meses: Q
2º 6 meses: W
Detiene el sketch: A
Reanuda el sketch: S
Captura de pantalla: C