

# Certamen 2: Visualización de Datos 

Nombre: Renata Vásquez 
Profesor: Nicolás Troncoso
Fecha: 3/06/2019


En mi certamen he utilizado los Datos de Velocidad Máxima y media de viento como los dos parámetros más importantes. También existe el uso de las variables de ángulo de del viento que permiten agregar detalles y más información al código. 

La primera visualización hace referencia a un año completo de viento , donde las coordenadas de cada uno de los círculos que respresenta un día se ve indicado por (x,y) como (velocidad máxima de viento, velocidad media de viento)  y el tamaño hace alusión al ángulo de viento que se registró aquel día, por tanto, a mayor tamaño mayor ángulo. 

La segunda visualización hace referencia a los mismos datos pero esta vez sólo al mes de enero. Estas se visualizan mediante barras cuyo inicio en el canvas comienza en el punto medio de viento y termina en el punto máximo.  

Por último, la tercera visualización representa la data correspondiente a los mismos parámetros ya mencionados pero haciendo alusión a una semana.

En conclusión, al momento de explorar no tuve dificultades en comprender cómo es el tratamiento de los datos, sin embargo al momento de querer ejecutar lo que tenía como idea principal se me hizo emuy muy díficil, ya que tratar con coordenadas fue algo muy distinto a lo que había visto. 









