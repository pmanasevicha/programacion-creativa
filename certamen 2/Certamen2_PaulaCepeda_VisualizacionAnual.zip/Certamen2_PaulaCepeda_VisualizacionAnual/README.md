Programación Creativa 2019/1 - Universidad del Desarrollo 
Paula Cepeda

# Certamen 2: Visualización de Datos


La tarea consistió en crear una visualización de una base de datos (un archivo .csv), la cual registra el clima en un lugar determinado. 

Tras elegir los datos apropiados a visualizar: Eventos atmosféricos y velocidad del viento (esta decisión fue tomada según cuanto variaban los datos a lo largo del año), se exploró el como llamar y trabajar la data desde Processing, y como visualizar de forma cómoda y clara. 


INSTRUCCIONES:

La visualización en su estado predeterminado, muestra la velocidad de los vientos y el evento atmosférico de cada día, agrupados mensualmente.
Para cambiar de escala se utilizan las siguientes teclas:

- A = Nos muestra todos los días del año superpuestos como elipses.
- M = Nos muestra el detalle mes a mes, con los días superpuestos.
- S = Nos muestra semana a semana, días superpuestos.
- D = Nos muestra día a día. No logré que leyera el color del evento atmosférico.