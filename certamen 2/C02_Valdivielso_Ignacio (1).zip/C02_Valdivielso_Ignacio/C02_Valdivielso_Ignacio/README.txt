Certamen 02: Visualizaci�n e interpretaci�n de datos
Ramo: Programaci�n Creativa
Nombre: Ignacio Valdivielso Valenzuela
Profesor: Nicol�s Troncoso Lopez
El objetivo del c�digo es representar 2 visualizaciones con variables diferentes, Temperatura (M�xima, M�nima y Media) para ver el comportamiento de esta durante los 365 d�as del a�o en el 2015, adem�s de incluir tambi�n las precipitaciones del a�o completo. 
En la visualizaci�n se pueden observar 3 tipos de puntos que indican la max, min y media, la exterior representa la m�xima de temperatura, la interior la m�nima y la que se encuentra en el rango de temperatura representa la media de estos 2 puntos. 
La otra visualizaci�n muestra el promedio de los niveles de la presi�n del mar durante el a�o, pero dividida en los 12 meses. Estas presentan 3 figuras que indican la m�xima, m�nima y media de los niveles de presi�n del mar, con 12 puntos de marcan sus niveles durante cada mes, hasta el periodo completo del a�o.

Asignaci�n de teclas:

La tecla Q es para poder ver la visualizaci�n de la Temperatura.

La tecla W es para poder ver la visualizaci�n de los Niveles de presi�n del Mar.
    
